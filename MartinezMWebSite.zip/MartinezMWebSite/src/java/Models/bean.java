package Models;

public class bean 
{
    protected String climate;
    protected int numDays;
    protected String myDropdown;
    
    public bean()
    {
    }
    public void setClimate(String climate)
    {
        this.climate = climate;
    }
    public String getClimate()
    {
        if(isValidClimate())
            return climate;
        return "*Cold";
    }
    public boolean isValidClimate()
    {
        return climate != null && !climate.trim().equals("");
    }
    public void setNumDays(Integer numDays)
    {
        this.numDays = numDays;
    }
    public int getNumDays()
    {
        if(isValidNumDays())
            return numDays;
        return 1;
    }
    public boolean isValidNumDays()
    {
        return numDays > 0;
    }
    public void setMyDropdown(String myDropdown)
    {
        this.myDropdown = myDropdown;
    }
    public String getMyDropdown()
    {
        if(isValidDropdown())
            return myDropdown;
        return "*Swimming";
    }
    public boolean isValidDropdown()
    {
        return myDropdown != null;
    }
    public String getValues()
    {
        return "Climate:  " + getClimate() + "| \nDays:  " + getNumDays() + "| \nPreferred Activity:  " + getMyDropdown();
    }
}
