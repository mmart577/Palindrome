package Controllers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.bean;
import Shared.HelperBase;
import javax.servlet.http.HttpServlet;

public class ControllerHelper extends HelperBase
{    
    protected bean myBean;
    
    public ControllerHelper(HttpServlet servlet, HttpServletRequest request, HttpServletResponse response)
    {
        super(servlet, request, response);    
        myBean = new bean();
    }
    
    public bean getBean()
    {
        return myBean; 
    }
    @Override
    public void copyFromSession(Object sessionHelper)
    {
        if(sessionHelper.getClass() == this.getClass())
        {
            myBean = ((ControllerHelper)sessionHelper).myBean;
        }
    }
    @Override
    public void addHelperToSession(String name, SessionData state)
    {
        if(SessionData.READ == state)
        {
            Object sessionObj = request.getSession().getAttribute(name);
            
            if(sessionObj != null)
                copyFromSession(sessionObj);
        }
        request.getSession().setAttribute(name, this);
    }
    public void doGet() throws ServletException, IOException
    {
        addHelperToSession("myHelper", SessionData.READ);
                
        String address;
        
        if(request.getParameter("processButton") != null)
        {
            address = "/Process.jsp";
        }
        else if(request.getParameter("confirmButton") != null)
        {        
            myBean.setClimate(request.getParameter("climate"));
            myBean.setNumDays(Integer.parseInt(request.getParameter("numDays")));
            myBean.setMyDropdown(request.getParameter("myDropdown"));
            
            address = "/Confirm.jsp";
        }
        else if(request.getParameter("wishlistButton") != null)
        {
            address = "/WishList.jsp";
        }
        else
        {
            address = "/Edit.jsp";
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);
    }
}
