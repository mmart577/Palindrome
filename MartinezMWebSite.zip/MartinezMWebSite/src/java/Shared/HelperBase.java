package Shared;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class HelperBase 
{
    protected HttpServletRequest request;
    protected HttpServletResponse response;
    protected HttpServlet servlet;
    
    public HelperBase(HttpServlet servlet, HttpServletRequest request, HttpServletResponse response)
    {
        this.servlet = servlet;
        this.request = request;
        this.response = response;
    }
    
    protected abstract void copyFromSession(Object helper);
    
    public abstract void addHelperToSession(String name, SessionData state);
    
    public enum SessionData
    {
        READ, IGNORE;
    }
}
